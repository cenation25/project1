from django.db import models


class UserModel(models.Model):
    uid = models.TextField(primary_key=True)
    uname = models.TextField()
    upassword = models.TextField()
    uarea = models.TextField()
    uskills = models.TextField()
    umobile = models.TextField()

    class Meta:
        db_table = 'tblUser'


class UploadModel(models.Model):
    upid = models.TextField(primary_key=True)
    update = models.TextField()
    upsubject = models.TextField()
    uptype = models.TextField()
    upvideolink = models.TextField()

    class Meta:
        db_table = 'tblUploads'
